https://crimson206.github.io/internal-link-handler

https://crimson206.github.io/internal-link-handler/?path=/story/docs--read-me

https://crimson206.github.io/internal-link-handler/?path=/story/example--with-internal-link-handler
https://crimson206.github.io/internal-link-handler/?path=/story/example--without-internal-link-handler